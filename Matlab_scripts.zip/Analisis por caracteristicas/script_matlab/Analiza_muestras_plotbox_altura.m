
function Analiza_muestras_plotbox_altura(umbral_alturas)
bases_datos=dir('BaseDatos_0*.mat');

datasets={'DLR Dataset' 'MobiFall Dataset' 'MobiAct Dataset' 'TST Fall detection  Dataset' 'tFall Teruel-Fall  Dataset' 'UR Fall Detection Dataset' 'Cogent Labs Dataset' 'Gravity Project Dataset' 'Graz Dataset' 'UMAFall Dataset' 'SisFall Dataset' 'UniMiB Dataset' 'FARSEEING'};
if (nargin==0) umbral_alturas=175; end;
alturas_titulos={['Under ' num2str(umbral_alturas), ' cm'],['Over ' num2str(umbral_alturas), ' cm']};
contador_Excel=2;


filename = ['Results_Height_',num2str(umbral_alturas),'.xlsx'];

%muestra_a_analizar={1,3,7,10,11,13}
for muestra_a_analizar={1,3,7,10,11,13}
  indice_muestra=muestra_a_analizar{1};
 load(bases_datos(indice_muestra).name);
 num_muestras=max(size(muestras));

% Inicializaci�n de vectores de medidas
SVM_maximo=[];
SVM_minimo=[];
SVM_dif_maximo=[];
SVM_media_intervalo=[];
axayaz_dif_max=[];

indice_tipos=[];
indice_subtipos=[];
indice_categoria_subtipos=[];
indice_posicion_acelerometro=[];
indice_alturas=[];


%num_muestras=5  ;
for contador=1:num_muestras
  
  %numero_acelerometros=sum(muestras(contador).Sensor_types=='A');
  numero_acelerometros=1;
  
  posiciones_acelerometros=cellstr(muestras(contador).Positions(muestras(contador).Sensor_types=='A',:));

  %Para cada aceler�metro presente en la muestra c�lculo las m�tricas
  acelerometros_vacios=0;
  for contador_acelerometros=1:numero_acelerometros
      Acelerometro=['Accelerometer_',num2str(contador_acelerometros)];
      if indice_muestra==7 %En la muestra de Cogent Labs el aceler�metro 2 es el de la cintura
          Acelerometro=['Accelerometer_2'];
      end
      if indice_muestra==10 %En la muestra de M�laga Labs el aceler�metro 3 es el de la cintura (no est�n todas las muestras)
          Acelerometro=['Accelerometer_3'];
      end
      %if indice_muestra==10 %En la muestra de M�laga Labs el aceler�metro 1 es el del m�vil (bolsillo)
      %    Acelerometro=['Accelerometer_1'];
      %end
      a=muestras(contador).(Acelerometro);
      if (length(a)>10)&not(isempty(a)) %Si hay muestras de aceleraci�n
        svm=sqrt(a(:,2).^2+a(:,3).^2+a(:,4).^2);
        SVM_maximo=[SVM_maximo,max(svm)];
        SVM_minimo=[SVM_minimo,min(svm)];
        SVM_dif_maximo=[SVM_dif_maximo, max(abs(svm(2:end)-svm(1:end-1)))];
       
        %Calculo el valor m�ximo de la se�al promediada con una ventana
        %deslizante de 1 segundo
        periodo=(max(a(:,1))-min(a(:,1)))/length(a(:,1)); %periodo de muestreo
        ventana=1; %1 segundo de ventana de an�lisis
        num_muestras_ventana=round(ventana/periodo);
        svm_filtrada=filter(ones(1,num_muestras_ventana),1,svm)/num_muestras_ventana; %filtro la se�al con una ventana de num_muestras_ventanas (media promedidada en esa ventana deslizante)

        SVM_media_intervalo=[SVM_media_intervalo, max(svm_filtrada)];
        
        %Se calcula el valor m�ximo del cambio absoluto en cualquier eje de
        %una muestra a otra
        maxdifax=max(abs((a(2:end,2)-a(1:end-1,2))));
        maxdifay=max(abs((a(2:end,3)-a(1:end-1,3))));
        maxdifaz=max(abs((a(2:end,4)-a(1:end-1,4))));
        axayaz_dif_max=[axayaz_dif_max, max([maxdifax,maxdifay,maxdifaz])];
 
        
        indice_tipos=[indice_tipos,cellstr(muestras(contador).Type_description)];
        indice_subtipos=[indice_subtipos,cellstr(muestras(contador).Subtype)];
        indice_alturas=[indice_alturas,muestras(contador).Height];
        indice_categoria_subtipos=[indice_categoria_subtipos,cellstr(muestras(contador).ADL_Category)];
        indice_posicion_acelerometro=[indice_posicion_acelerometro;posiciones_acelerometros(contador_acelerometros+acelerometros_vacios)];    
      else
          %disp([datasets(indice_muestra), ' Muestra vac�a:', num2str(contador)]);
      end
      if isempty(a)
          acelerometros_vacios=acelerometros_vacios-1; %Si hay un aceler�metro vac�o (sin muestras), decremento el �ndice 
      end
  end
 
  
end
indice_posicion_acelerometro=indice_posicion_acelerometro';

posiciones_posibles=unique(indice_posicion_acelerometro);

tipos_posibles=unique(indice_categoria_subtipos); indice_tipos=indice_categoria_subtipos;

%tipos_posibles={'Falls'};   %%%%%

vector_para_plotbox_SVM_maximo=[];
vector_para_plotbox_SVM_minimo=[];
vector_para_plotbox_SVM_dif_maximo=[];
vector_para_plotbox_SVM_media_intervalo=[];
vector_para_plotbox_axayaz_dif_max=[];

%------------------------------Se toma s�lo la primera posici�n del aceler�metro

filtro_para_plotbox=[];

generos_posibles={'F','M'};
posiciones_posibles=1; %S�lo se tiene en cuenta la primera posici�n

%figure('units','normalized','outerposition',[0 0 1 1])


for contador_posicion=1:length(posiciones_posibles)
   condicion_posicion=strcmp(indice_posicion_acelerometro,posiciones_posibles(contador_posicion));
   contador_series=1;
   for contador_subtipo=1:length(tipos_posibles)
       for alturas=1:2
          condicion_tipo=strcmp(indice_tipos,tipos_posibles(contador_subtipo));
          
          if (alturas==1)
            condicion_individuo=(indice_alturas<umbral_alturas);
          else
            condicion_individuo=(indice_alturas>=umbral_alturas);
          end

          %condicion_elegida=condicion_posicion&condicion_tipo;
          condicion_elegida=condicion_tipo&condicion_individuo; %S�lo se tiene en cuenta el tipo y el altura (no la posici�n, si es que esta var�a de una muestra a otra)

          SVM_maximo_filtrado=SVM_maximo(condicion_elegida)';  
          SVM_minimo_filtrado=SVM_minimo(condicion_elegida)';  
          SVM_dif_maximo_filtrado=SVM_dif_maximo(condicion_elegida)';  
          SVM_media_intervalo_filtrado=SVM_media_intervalo(condicion_elegida)';  
          axayaz_dif_max_filtrado=axayaz_dif_max(condicion_elegida)';

          vector_para_plotbox_SVM_maximo=[vector_para_plotbox_SVM_maximo;SVM_maximo_filtrado];
          vector_para_plotbox_SVM_minimo=[vector_para_plotbox_SVM_minimo;SVM_minimo_filtrado];
          vector_para_plotbox_SVM_dif_maximo=[vector_para_plotbox_SVM_dif_maximo;SVM_dif_maximo_filtrado];
          vector_para_plotbox_SVM_media_intervalo=[vector_para_plotbox_SVM_media_intervalo;SVM_media_intervalo_filtrado];
          vector_para_plotbox_axayaz_dif_max=[vector_para_plotbox_axayaz_dif_max;axayaz_dif_max_filtrado];

          filtro_para_plotbox=[filtro_para_plotbox;SVM_maximo_filtrado*0+contador_series]; %filtro necesario para distinguir valores con boxplot
          titulos{contador_series}=[tipos_posibles{contador_subtipo},' (', alturas_titulos{alturas},')'];
          contador_series=contador_series+1;
         %pause
       end %alturas
   end %Subtipo

   no_estadisticos=4;

  %--------------------------AN�LISIS ANOVA

   for estadistico={'SVM_maximo','SVM_minimo','SVM_dif_maximo','SVM_media_intervalo','axayaz_dif_max'}
   
       
       variable=eval(['vector_para_plotbox_',char(estadistico)]); 

       cabecero_Excel={'Dataset';'Movement type'; 'Statistic';'P-value';['Mean (' alturas_titulos{1} ')']; ['Mean (' alturas_titulos{2} ')'];['Std (' alturas_titulos{1} ')']; ['Std(' alturas_titulos{2} ')'];['Number of samples(' alturas_titulos{1} ')'];['Number of samples((' alturas_titulos{2} ')']};
       xlswrite(filename,cabecero_Excel',1,'A1');
       %disp(cabecero_Excel');
       for contador_subtipo=1:length(tipos_posibles)
          filtro_mujeres=(filtro_para_plotbox==(contador_subtipo*2-1)); %Selecciono los valores de las mujeres para cierto subtipo
          filtro_hombres=(filtro_para_plotbox==(contador_subtipo*2)); %Selecciono los valores de los hombres para cierto subtipo
          vm=variable(filtro_mujeres);
          vh=variable(filtro_hombres);
          pvalue=anova1([vm;vh],[vm*0;vh*0+1],'off');
           disp([datasets{indice_muestra},' ',tipos_posibles{contador_subtipo}, ' ',char(estadistico),' p-value (ANOVA analysis)',num2str(pvalue),' Mean(<Threshold):', num2str(mean(vm)),' Mean(>Threshold):', num2str(mean(vh))]);
          resultados={datasets{indice_muestra};tipos_posibles{contador_subtipo};char(estadistico); pvalue; mean(vm); mean(vh); std(vm); std(vh); length(vm); length(vh)};
          xlswrite(filename,resultados',1,['A' num2str(contador_Excel)]);
          contador_Excel=contador_Excel+1;
       end  
   end   
   
   %--------------------------GR�FICOS BOXPLOT
   
       %titulos=subtipos_posibles;
       %titulos={'Bending'    'Go downstairs'    'Go upstairs'    'Hopping'    'Jogging'    'Lie down on a bed'  'Sit & get up from a chair'    'Walking'    'Backward fall'    'Forward Fall'    'Lateral Fall'};
       %titulos={'ADL1'    'ADL2'    'ADL3'    'ADL4'    'ADL5'    'ADL6'  'ADL7'    'ADL8'    'Fall1'    'Fall2'    'Fall3'};
 
          Tam_letra=17;
           rotation=0;

   labels_ejex={'Maximum SMV (g)','Minimum SMV (g)','Maximum absolute differentiated SMV (g)','Maximum averaged SMV (g)', 'Maximum variation of the accelaration in any axis (g)'};
   contador_label=1;
   for estadistico={'SVM_maximo','SVM_minimo','SVM_dif_maximo','SVM_media_intervalo','axayaz_dif_max'}

       vector=eval(['vector_para_plotbox_',char(estadistico)]);        
       boxplot(vector,filtro_para_plotbox,'Labels',titulos(1:max(filtro_para_plotbox)),'Orientation' ,'horizontal');
       xlabel(labels_ejex(contador_label));
       title(datasets{indice_muestra});
       set(gca,'FontSize',Tam_letra,'XTickLabelRotation',rotation)
       contador_label=contador_label+1;
       %pause
   end
   
   
   
end %posiciones_posibles



end %Muestra a analizar



file=filename;
file_salida = file;
hoja_salida=2;
alpha=0.05; %significance level

[num,txt,raw]=xlsread(file);

p_values=cell2mat(raw(2:end,4));
dataset=raw(2:end,1);
tipos_movimientos=raw(2:end,2);
tipos_estadisticos=raw(2:end,3);

movimientos_posibles=unique(tipos_movimientos);
estadisticos_posibles=unique(tipos_estadisticos);


cabecera_archivo{1}=['Movement type'];
for contador=1:length(estadisticos_posibles)
    cabecera_archivo{contador+1}=estadisticos_posibles{contador};
end

xlswrite(file_salida,{'Number of datasets with disimilarities that have statistical significance'},hoja_salida,'A1');
xlswrite(file_salida,cabecera_archivo,hoja_salida,'A2');


for contador_movimiento=1:length(movimientos_posibles)
    xlswrite(file_salida,movimientos_posibles(contador_movimiento),hoja_salida,['A' num2str(contador_movimiento+2)]);
    condicion_movimiento=strcmp(tipos_movimientos,movimientos_posibles{contador_movimiento});
    for contador_estadistico=1:length(estadisticos_posibles)
         condicion_estadistico=strcmp(tipos_estadisticos,estadisticos_posibles{contador_estadistico});
         condicion_total=condicion_estadistico&condicion_movimiento;
         
         datasets_significativos{contador_estadistico}=[num2str(sum(p_values(condicion_total)<alpha)) ' out of ' num2str(length(p_values(condicion_total)))]; 
    end
    xlswrite(file_salida,datasets_significativos,hoja_salida,['B' num2str(contador_movimiento+2)]);
end


Procesa_hojas_excel_caracteristicas(filename)







