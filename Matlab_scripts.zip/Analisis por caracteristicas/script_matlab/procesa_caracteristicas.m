Analiza_muestras_plotbox_altura(170);
Analiza_muestras_plotbox_altura(175); 
Analiza_muestras_plotbox_peso(70); 
Analiza_muestras_plotbox_peso(80);
Analiza_muestras_plotbox_edad(30);
Analiza_muestras_plotbox_edad(40);
Analiza_muestras_plotbox_genero2;