
%clear
%file='Results_Height_175.xlsx';
function Procesa_hojas_excel_caracteristicas(file,alpha,hoja_inicial)
% function Procesa_hojas_excel_caracteristicas(file,alpha,hoja_salida)
% Esta funci�n toma el archivo excel resultante de la funci�n
% Analiza_muestras_plotbox_muestras y calcula para cada tipo de movimiento
% y cada estad�sticos cu�ntos datasets presentan diferencias significativas
% en funci�n de las variables consideradas (g�nero, peso, altura, edad).
% Los resultados los vuelca en el mismo documento Excel pero en dos p�ginas distintas: una indica el n�mero de datasets con diferencias significativas
% y otra los datasets donde se dan esas diferencias. Se permite definir
% varios alphas (para la significancia)
% Entradas:
%     file: hoja excel resultado de  Analiza_muestras_plotbox_muestras
%     alpha: vector con los valores de la significaci�n estad�stica
%            (1-0,95) que se desea. Por defecto alpha=2.
%     hoja_salida: n�mero de la primera hoja del excel que se emplear� (por
%            defecto es la 2)
%

file_salida = file;

if (nargin<2)
 alpha=0.05; %significance level
end

if (nargin<3)
 hoja_inicial=2; %Hojas del excel en la que se escriben los resultados
end

[num,txt,raw]=xlsread(file);

p_values=cell2mat(raw(2:end,4));
dataset=raw(2:end,1);
tipos_movimientos=raw(2:end,2);
tipos_estadisticos=raw(2:end,3);

movimientos_posibles=unique(tipos_movimientos);
estadisticos_posibles=unique(tipos_estadisticos);


cabecera_archivo{1}=['Movement type'];
for contador=1:length(estadisticos_posibles)
    cabecera_archivo{contador+1}=estadisticos_posibles{contador};
end

for indice_alpha=1:length(alpha)
    
        alpha_actual=alpha(indice_alpha);
        hoja_salida=hoja_inicial+(indice_alpha-1)*2;
        xlswrite(file_salida,{['Number of datasets with disimilarities that have statistical significance with ALPHA=',num2str(alpha_actual)]},hoja_salida,'A1');
        xlswrite(file_salida,cabecera_archivo,hoja_salida,'A2');

        xlswrite(file_salida,{['Names of datasets with disimilarities that have statistical significance with ALPHA=',num2str(alpha_actual)]},hoja_salida+1,'A1');
        xlswrite(file_salida,cabecera_archivo,hoja_salida+1,'A2');


        for contador_movimiento=1:length(movimientos_posibles)
            xlswrite(file_salida,movimientos_posibles(contador_movimiento),hoja_salida,['A' num2str(contador_movimiento+2)]);
            xlswrite(file_salida,movimientos_posibles(contador_movimiento),hoja_salida+1,['A' num2str(contador_movimiento+2)]);
            condicion_movimiento=strcmp(tipos_movimientos,movimientos_posibles{contador_movimiento});
            for contador_estadistico=1:length(estadisticos_posibles)
                 condicion_estadistico=strcmp(tipos_estadisticos,estadisticos_posibles{contador_estadistico});
                 condicion_total=condicion_estadistico&condicion_movimiento;

                 datasets_posibles=(dataset(condicion_total));
                 p_values_estadistico=p_values(condicion_total);
                 cadena=[''];
                 for contador_datasets=1:length(datasets_posibles)
                     if (p_values_estadistico(contador_datasets)<alpha_actual)
                         if length(cadena)>0
                            cadena=[cadena,','];
                         end
                         cadena=[cadena,datasets_posibles{contador_datasets}];
                     end
                 end
                 numero_de_muestras_analizadas=length(p_values(condicion_total))-sum(isnan(p_values(condicion_total))); %Se restan aquellas muestras para las que p_value es NaN porque faltan ejemplos de una de las condiciones
                 no_datasets_significativos{contador_estadistico}=[num2str(sum(p_values(condicion_total)<alpha_actual)) ' out of ' num2str(numero_de_muestras_analizadas)]; 
                 datasets_significativos{contador_estadistico}=cadena;
            end
            xlswrite(file_salida,no_datasets_significativos,hoja_salida,['B' num2str(contador_movimiento+2)]);
            xlswrite(file_salida,datasets_significativos,hoja_salida+1,['B' num2str(contador_movimiento+2)]);

        end

end