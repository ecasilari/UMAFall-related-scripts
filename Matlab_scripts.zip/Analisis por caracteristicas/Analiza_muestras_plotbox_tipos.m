clear
bases_datos=dir('BaseDatos_0*.mat');

vector_para_plotbox_SVM_maximo_todas=[];
vector_para_plotbox_SVM_minimo_todas=[];
vector_para_plotbox_SVM_dif_maximo_todas=[];
vector_para_plotbox_SVM_media_intervalo_todas=[];
filtro_para_plotbox_SVM_maximo_todas=[];
contador_todas=1;

for i=1:length(bases_datos)
 load(bases_datos(i).name);
 num_muestras=max(size(muestras));

% Inicializaci�n de vectores de medidas
SVM_maximo=[];
SVM_minimo=[];
SVM_dif_maximo=[];
SVM_media_intervalo=[];

indice_tipos=[];
indice_subtipos=[];
indice_categoria_subtipos=[];
indice_posicion_acelerometro=[];

%num_muestras=5  ;
for contador=1:num_muestras
  
  %numero_acelerometros=sum(muestras(contador).Sensor_types=='A');
  numero_acelerometros=1;
  
  posiciones_acelerometros=cellstr(muestras(contador).Positions(muestras(contador).Sensor_types=='A',:));

  %Para cada aceler�metro presente en la muestra c�lculo las m�tricas
  acelerometros_vacios=0;
  for contador_acelerometros=1:numero_acelerometros
      Acelerometro=['Accelerometer_',num2str(contador_acelerometros)];
      if i==7 %En la muestra de Cogent Labs el aceler�metro 2 es el de la cintura
          Acelerometro=['Accelerometer_2'];
      end
      if i==10 %En la muestra de M�laga Labs el aceler�metro 3 es el de la cintura
          Acelerometro=['Accelerometer_3'];
      end
      a=muestras(contador).(Acelerometro);
      if (length(a)>10)&not(isempty(a)) %Si hay muestras de aceleraci�n
        svm=sqrt(a(:,2).^2+a(:,3).^2+a(:,4).^2);
        SVM_maximo=[SVM_maximo,max(svm)];
        SVM_minimo=[SVM_minimo,min(svm)];
        SVM_dif_maximo=[SVM_dif_maximo, max(abs(svm(2:end)-svm(1:end-1)))];
        
        %Calculo el valor m�ximo de la se�al promediada con una ventana
        %deslizante de 1 segundo
        periodo=(max(a(:,1))-min(a(:,1)))/length(a(:,1)); %periodo de muestreo
        ventana=1; %1 segundo de ventana de an�lisis
        num_muestras_ventana=round(ventana/periodo);
        svm_filtrada=filter(ones(1,num_muestras_ventana),1,svm)/num_muestras_ventana; %filtro la se�al con una ventana de num_muestras_ventanas (media promedidada en esa ventana deslizante)

        SVM_media_intervalo=[SVM_media_intervalo, max(svm_filtrada)];
       
        indice_tipos=[indice_tipos,cellstr(muestras(contador).Type_description)];
        indice_subtipos=[indice_subtipos,cellstr(muestras(contador).Subtype)];
        indice_categoria_subtipos=[indice_categoria_subtipos,cellstr(muestras(contador).ADL_Category)];
        indice_posicion_acelerometro=[indice_posicion_acelerometro;posiciones_acelerometros(contador_acelerometros+acelerometros_vacios)];    
      end
      if isempty(a)
          acelerometros_vacios=acelerometros_vacios-1; %Si hay un aceler�metro vac�o (sin muestras), decremento el �ndice 
      end
  end
  %length(SVM_maximo)
  %length(indice_subtipos)
  
end
indice_posicion_acelerometro=indice_posicion_acelerometro';

posiciones_posibles=unique(indice_posicion_acelerometro);

%tipos_posibles=sort(unique(indice_tipos)); %aqu� elegimos si queremos distinguir entre tipos o entre subtipos o categor�as de subtipos
%tipos_posibles=unique(indice_subtipos); indice_tipos=indice_subtipos;
tipos_posibles=unique(indice_categoria_subtipos); indice_tipos=indice_categoria_subtipos;


vector_para_plotbox_SVM_maximo=[];
vector_para_plotbox_SVM_minimo=[];
vector_para_plotbox_SVM_dif_maximo=[];
vector_para_plotbox_SVM_media_intervalo=[];

%------------------------------Se toma s�lo la primera posici�n del aceler�metro

filtro_para_plotbox_SVM_maximo=[];

posiciones_posibles=1; %S�lo se tiene en cuenta la primera posici�n
for contador_posicion=1:length(posiciones_posibles)
   condicion_posicion=strcmp(indice_posicion_acelerometro,posiciones_posibles(contador_posicion));
   for contador_subtipo=1:length(tipos_posibles)
      condicion_tipo=strcmp(indice_tipos,tipos_posibles(contador_subtipo));
   
      %condicion_elegida=condicion_posicion&condicion_tipo;
      condicion_elegida=condicion_tipo; %S�lo se tiene en cuenta el tipo (no la posici�n, si es que esta var�a de una muestra a otra)
      
      SVM_maximo_filtrado=SVM_maximo(condicion_elegida)';  
      SVM_minimo_filtrado=SVM_minimo(condicion_elegida)';  
      SVM_dif_maximo_filtrado=SVM_dif_maximo(condicion_elegida)';  
      SVM_media_intervalo_filtrado=SVM_media_intervalo(condicion_elegida)';  
      
      vector_para_plotbox_SVM_maximo=[vector_para_plotbox_SVM_maximo;SVM_maximo_filtrado];
      vector_para_plotbox_SVM_maximo_todas=[vector_para_plotbox_SVM_maximo_todas;SVM_maximo_filtrado];
      vector_para_plotbox_SVM_minimo=[vector_para_plotbox_SVM_minimo;SVM_minimo_filtrado];
      vector_para_plotbox_SVM_minimo_todas=[vector_para_plotbox_SVM_minimo_todas;SVM_minimo_filtrado];
      vector_para_plotbox_SVM_dif_maximo=[vector_para_plotbox_SVM_dif_maximo;SVM_dif_maximo_filtrado];
      vector_para_plotbox_SVM_dif_maximo_todas=[vector_para_plotbox_SVM_dif_maximo_todas;SVM_dif_maximo_filtrado];
      vector_para_plotbox_SVM_media_intervalo=[vector_para_plotbox_SVM_media_intervalo;SVM_media_intervalo_filtrado];
      vector_para_plotbox_SVM_media_intervalo_todas=[vector_para_plotbox_SVM_media_intervalo_todas;SVM_media_intervalo_filtrado];
      filtro_para_plotbox_SVM_maximo=[filtro_para_plotbox_SVM_maximo;SVM_maximo_filtrado*0+contador_subtipo]; %filtro necesario para distinguir valores con boxplot
      filtro_para_plotbox_SVM_maximo_todas=[filtro_para_plotbox_SVM_maximo_todas;SVM_maximo_filtrado*0+contador_todas];
      contador_todas=contador_todas+1;
      %pause
   end
   %titulos=subtipos_posibles;
   %titulos={'Bending'    'Go downstairs'    'Go upstairs'    'Hopping'    'Jogging'    'Lie down on a bed'  'Sit & get up from a chair'    'Walking'    'Backward fall'    'Forward Fall'    'Lateral Fall'};
   %titulos={'ADL1'    'ADL2'    'ADL3'    'ADL4'    'ADL5'    'ADL6'  'ADL7'    'ADL8'    'Fall1'    'Fall2'    'Fall3'};
titulos=tipos_posibles;
   

datasets={'DLR Dataset' 'MobiFall Dataset' 'MobiAct Dataset' 'TST Fall detection  Dataset' 'tFall Teruel-Fall  Dataset' 'UR Fall Detection Dataset' 'Cogent Labs Dataset' 'Gravity Project Dataset' 'Graz Dataset' 'UMAFall Dataset' 'SisFall Dataset' 'UniMiB Dataset'};


   Tam_letra=22;
   rotation=0;

   
   if (false) %Maximum SMV (g)
   
       figure('units','normalized','outerposition',[0 0 1 1])
       boxplot(vector_para_plotbox_SVM_maximo,filtro_para_plotbox_SVM_maximo,'Labels',titulos);
       %ylabel('Maximum value of the acceleration magnitude (g)');
       ylabel('Maximum SMV (g)');
       title(char(datasets(i)));
       set(gca,'FontSize',Tam_letra,'XTickLabelRotation',rotation)
       pause
       close 
   end
   if (false) %Minimum SMV (g)
       figure('units','normalized','outerposition',[0 0 1 1])
       boxplot(vector_para_plotbox_SVM_minimo,filtro_para_plotbox_SVM_maximo,'Labels',titulos);
       %ylabel('Minimum value of the acceleration magnitude (g)');
       ylabel('Minimum SMV (g)');
       title(char(datasets(i)));
       set(gca,'FontSize',Tam_letra,'XTickLabelRotation',rotation)
       pause
       close
   end
   
  if (false)
         figure('units','normalized','outerposition',[0 0 1 1])
       boxplot(vector_para_plotbox_SVM_dif_maximo,filtro_para_plotbox_SVM_maximo,'Labels',titulos);
       %ylabel('Maximum absolute value of the differentiated acceleration magnitude (g)');
       ylabel('Maximum absolute differentiated SMV (g)');
       title(char(datasets(i)));
       set(gca,'FontSize',Tam_letra,'XTickLabelRotation',rotation)
       pause
       close
  end
  if (true)

       figure('units','normalized','outerposition',[0 0 1 1])
       boxplot(vector_para_plotbox_SVM_media_intervalo,filtro_para_plotbox_SVM_maximo,'Labels',titulos);
       %ylabel('Maximum averaged acceleration magnitude for a sliding window of 1 s (g)');
       ylabel('Maximum averaged SMV (g)');
       title(char(datasets(i)));
       set(gca,'FontSize',Tam_letra,'XTickLabelRotation',rotation)
       pause
       close
   end 
   
end

end


% DIBUJAR TODOS LOS BOXPLOTS ADLS/FALLS
datasets_cambiados=strrep(datasets,'Dataset','');
datasets_cambiados=strrep(datasets_cambiados,'Fall detection','');
datasets_cambiados=strrep(datasets_cambiados,'Fall Detection','');
datasets_cambiados=strrep(datasets_cambiados,'Teruel-Fall','');

for contador=0:11
    nombre_muestras{contador*2+1}=[char(datasets_cambiados(contador+1)),'(ADL)'];
    nombre_muestras{contador*2+2}=[char(datasets_cambiados(contador+1)),'(Falls)'];
end

Tam_letra=15;
rotation=0;
figure('units','normalized','outerposition',[0 0 1 1])
   boxplot(vector_para_plotbox_SVM_maximo_todas,filtro_para_plotbox_SVM_maximo_todas,'Labels', nombre_muestras);
   ylabel('Maximum SMV (g)');
   title('All datasets');
   set(gca,'FontSize',Tam_letra,'XTickLabelRotation',rotation)
   pause
   close
   
       figure('units','normalized','outerposition',[0 0 1 1])
       boxplot(vector_para_plotbox_SVM_minimo_todas,filtro_para_plotbox_SVM_maximo_todas,'Labels',nombre_muestras);
       %ylabel('Minimum value of the acceleration magnitude (g)');
       ylabel('Minimum SMV (g)');
      title('All datasets');
       set(gca,'FontSize',Tam_letra,'XTickLabelRotation',rotation)
       pause
       close

       figure('units','normalized','outerposition',[0 0 1 1])
       boxplot(vector_para_plotbox_SVM_dif_maximo_todas,filtro_para_plotbox_SVM_maximo_todas,'Labels',nombre_muestras);
       %ylabel('Maximum absolute value of the differentiated acceleration magnitude (g)');
       ylabel('Maximum absolute differentiated SMV (g)');
       title('All datasets');
       set(gca,'FontSize',Tam_letra,'XTickLabelRotation',rotation)
       pause
       close

       figure('units','normalized','outerposition',[0 0 1 1])
       boxplot(vector_para_plotbox_SVM_media_intervalo_todas,filtro_para_plotbox_SVM_maximo_todas,'Labels',nombre_muestras);
       %ylabel('Maximum averaged acceleration magnitude for a sliding window of 1 s (g)');
       ylabel('Maximum averaged SMV (g)');
       title('All datasets');
       set(gca,'FontSize',Tam_letra,'XTickLabelRotation',rotation)
       pause
       close
   
   
   