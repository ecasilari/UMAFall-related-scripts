
function Analiza_muestras_plotbox_caracteristica(datasets_elegidos,acelerometros_elegidos,nombre_caracteristica,umbral_caracteristica)


if (nargin<3) 
    disp('Error:faltan argumentos');
    return
end;

archivos_datasets=datasets_elegidos(:,1);
nombres_datasets=datasets_elegidos(:,2);

nombre_caracteristica=lower(nombre_caracteristica);


if strcmp(nombre_caracteristica,'gender')
  caracteristica_titulos={['Females'],['Males']};
  umbral_caracteristica='F'; %Umbral: letra F (porque M>F)
else     
  if strcmp(nombre_caracteristica,'weight')
      unidades='kg';
  end
  if strcmp(nombre_caracteristica,'height')
      unidades='cm';
  end
  if strcmp(nombre_caracteristica,'age')
      unidades='years';
  end
  caracteristica_titulos={['Under ' num2str(umbral_caracteristica), ' ',unidades],['Over ' num2str(umbral_caracteristica),' ',unidades]};
end
contador_Excel=2;

filename = ['Results_',nombre_caracteristica,'_',num2str(umbral_caracteristica),'.xlsx'];



for contador_muestra=1:length(archivos_datasets)
  
    load([archivos_datasets{contador_muestra} '.mat']);
    num_muestras=max(size(muestras));

    % Inicializaci�n de vectores de medidas
    SVM_maximo=[];
    SVM_minimo=[];
    SVM_dif_maximo=[];
    SVM_media_intervalo=[];
    axayaz_dif_max=[];
    frecuencia_pico=[];

    indice_tipos=[];
    indice_subtipos=[];
    valores_categoria_subtipos=[];
    indice_posicion_acelerometro=[];
    valores_caracteristica=[];



    for contador=1:num_muestras

       %Para cada aceler�metro presente en la muestra c�lculo las m�tricas
      acelerometros_vacios=0;

          Acelerometro=['Accelerometer_' acelerometros_elegidos{contador_muestra}];

          a=muestras(contador).(Acelerometro);
          if (length(a)>10)&not(isempty(a)) %Si hay muestras de aceleraci�n
                svm=sqrt(a(:,2).^2+a(:,3).^2+a(:,4).^2);
                SVM_maximo=[SVM_maximo,max(svm)];
                SVM_minimo=[SVM_minimo,min(svm)];
                SVM_dif_maximo=[SVM_dif_maximo, max(abs(svm(2:end)-svm(1:end-1)))];

                %Calculo el valor m�ximo de la se�al promediada con una ventana
                %deslizante de 1 segundo
                periodo=(max(a(:,1))-min(a(:,1)))/length(a(:,1)); %periodo de muestreo
                ventana=1; %1 segundo de ventana de an�lisis
                num_muestras_ventana=round(ventana/periodo);
                svm_filtrada=filter(ones(1,num_muestras_ventana),1,svm)/num_muestras_ventana; %filtro la se�al con una ventana de num_muestras_ventanas (media promedidada en esa ventana deslizante)

                SVM_media_intervalo=[SVM_media_intervalo, max(svm_filtrada)];

                %Se calcula el valor m�ximo del cambio absoluto en cualquier eje de
                %una muestra a otra
                maxdifax=max(abs((a(2:end,2)-a(1:end-1,2))));
                maxdifay=max(abs((a(2:end,3)-a(1:end-1,3))));
                maxdifaz=max(abs((a(2:end,4)-a(1:end-1,4))));
                axayaz_dif_max=[axayaz_dif_max, max([maxdifax,maxdifay,maxdifaz])];
                
                %Se calcula el m�ximo componente frecuencial de la se�al SMV(tomando 2 segundos: 1
                %segundo antes y 1 despu�s del pico)
                [maximo, posicion_maximo]=max(svm);
                frecuencia_muestreo=1/periodo;
                intervalo_a_analizar=max((posicion_maximo-num_muestras_ventana),1):min((posicion_maximo+num_muestras_ventana),length(svm));              
                frecuencia_pico_actual=not_null_peak_frequency(svm(intervalo_a_analizar),frecuencia_muestreo);
                frecuencia_pico=[frecuencia_pico, frecuencia_pico_actual];
                

                if strcmp(nombre_caracteristica,'height')
                   valores_caracteristica=[valores_caracteristica,muestras(contador).Height];
                end    %height 
                if strcmp(nombre_caracteristica,'age')
                   valores_caracteristica=[valores_caracteristica,muestras(contador).Age];
                end    %age
                if strcmp(nombre_caracteristica,'weight')
                   valores_caracteristica=[valores_caracteristica,muestras(contador).Weight];
                end    %weight 
                if strcmp(nombre_caracteristica,'gender')
                   valores_caracteristica=[valores_caracteristica,strrep(muestras(contador).Gender,' ','')]; %Elimino posibles espacios en blanco
                end    %gender
                valores_categoria_subtipos=[valores_categoria_subtipos,cellstr(muestras(contador).ADL_Category)];
          else
              %disp([nombres_datasets(contador_muestra), ' Muestra vac�a:', num2str(contador)]);
          end        
    end %contador


    tipos_posibles=unique(valores_categoria_subtipos); 

    vector_para_plotbox_SVM_maximo=[];
    vector_para_plotbox_SVM_minimo=[];
    vector_para_plotbox_SVM_dif_maximo=[];
    vector_para_plotbox_SVM_media_intervalo=[];
    vector_para_plotbox_axayaz_dif_max=[];
    vector_para_plotbox_frecuencia_pico=[];


    filtro_para_plotbox=[];

   contador_series=1;
   for contador_subtipo=1:length(tipos_posibles)
       for caracteristica=1:2
          condicion_categoria_subtipo=strcmp(valores_categoria_subtipos,tipos_posibles(contador_subtipo));
          
          if (caracteristica==1)
            condicion_individuo=(valores_caracteristica<=umbral_caracteristica);
          else
            condicion_individuo=(valores_caracteristica>umbral_caracteristica);
          end

          %condicion_elegida=condicion_posicion&condicion_tipo;
          condicion_elegida=condicion_categoria_subtipo&condicion_individuo; %S�lo se tiene en cuenta el tipo y la caracter�stica elegida 
          SVM_maximo_filtrado=SVM_maximo(condicion_elegida)';  
          SVM_minimo_filtrado=SVM_minimo(condicion_elegida)';  
          SVM_dif_maximo_filtrado=SVM_dif_maximo(condicion_elegida)';  
          SVM_media_intervalo_filtrado=SVM_media_intervalo(condicion_elegida)';  
          axayaz_dif_max_filtrado=axayaz_dif_max(condicion_elegida)';
          frecuencia_pico_filtrado=frecuencia_pico(condicion_elegida)';

          vector_para_plotbox_SVM_maximo=[vector_para_plotbox_SVM_maximo;SVM_maximo_filtrado];
          vector_para_plotbox_SVM_minimo=[vector_para_plotbox_SVM_minimo;SVM_minimo_filtrado];
          vector_para_plotbox_SVM_dif_maximo=[vector_para_plotbox_SVM_dif_maximo;SVM_dif_maximo_filtrado];
          vector_para_plotbox_SVM_media_intervalo=[vector_para_plotbox_SVM_media_intervalo;SVM_media_intervalo_filtrado];
          vector_para_plotbox_axayaz_dif_max=[vector_para_plotbox_axayaz_dif_max;axayaz_dif_max_filtrado];
          vector_para_plotbox_frecuencia_pico=[vector_para_plotbox_frecuencia_pico;frecuencia_pico_filtrado];
          
          filtro_para_plotbox=[filtro_para_plotbox;SVM_maximo_filtrado*0+contador_series]; %filtro necesario para distinguir valores con boxplot
          titulos{contador_series}=[tipos_posibles{contador_subtipo},' (', caracteristica_titulos{caracteristica},')'];
          contador_series=contador_series+1;
         %pause
       end %caracteristica
   end %Subtipo



  %--------------------------AN�LISIS ANOVA

   for estadistico={'SVM_maximo','SVM_minimo','SVM_dif_maximo','SVM_media_intervalo','axayaz_dif_max','frecuencia_pico'}
   
       
       variable=eval(['vector_para_plotbox_',char(estadistico)]); 

       cabecero_Excel={'Dataset';'Movement type'; 'Statistic';'P-value';['Mean (' caracteristica_titulos{1} ')']; ['Mean (' caracteristica_titulos{2} ')'];['Std (' caracteristica_titulos{1} ')']; ['Std(' caracteristica_titulos{2} ')'];['Number of samples(' caracteristica_titulos{1} ')'];['Number of samples(' caracteristica_titulos{2} ')']};
       xlswrite(filename,cabecero_Excel',1,'A1');
       %disp(cabecero_Excel');
       for contador_subtipo=1:length(tipos_posibles)
          filtro_caracteristica_1=(filtro_para_plotbox==(contador_subtipo*2-1)); %Selecciono los valores de las mujeres para cierto subtipo
          filtro_caracteristica_2=(filtro_para_plotbox==(contador_subtipo*2)); %Selecciono los valores de los hombres para cierto subtipo
          vm=variable(filtro_caracteristica_1);
          vh=variable(filtro_caracteristica_2);
          pvalue=anova1([vm;vh],[vm*0;vh*0+1],'off');
           disp([nombres_datasets{contador_muestra},' ',tipos_posibles{contador_subtipo}, ' ',char(estadistico),' p-value (ANOVA analysis)',num2str(pvalue),' Mean(<Threshold):', num2str(mean(vm)),' Mean(>Threshold):', num2str(mean(vh))]);
          resultados={nombres_datasets{contador_muestra};tipos_posibles{contador_subtipo};char(estadistico); pvalue; mean(vm); mean(vh); std(vm); std(vh); length(vm); length(vh)};
          xlswrite(filename,resultados',1,['A' num2str(contador_Excel)]);
          contador_Excel=contador_Excel+1;
       end  %contador_subtipo
   end   
   
   %--------------------------GR�FICOS BOXPLOT
   

   Tam_letra=17;
   rotation=0;

   labels_ejex={'Maximum SMV (g)','Minimum SMV (g)','Maximum absolute differentiated SMV (g)','Maximum averaged SMV (g)', 'Maximum variation of the accelaration in any axis (g)', 'Peak frequency (Hz)'};
   contador_label=1;
   for estadistico={'SMV_maximo','SMV_minimo','SMV_dif_maximo','SMV_media_intervalo','axayaz_dif_max','frecuencia_pico'}

       vector=eval(['vector_para_plotbox_',char(estadistico)]);        
       boxplot(vector,filtro_para_plotbox,'Labels',titulos(unique(filtro_para_plotbox)),'Orientation' ,'horizontal');
       xlabel(labels_ejex(contador_label));
       title(nombres_datasets{contador_muestra});
       set(gca,'FontSize',Tam_letra,'XTickLabelRotation',rotation)
       contador_label=contador_label+1;
       %pause
   end
   
 end %Muestra a analizar



Procesa_hojas_excel_caracteristicas(filename, [0.05 0.01]);






