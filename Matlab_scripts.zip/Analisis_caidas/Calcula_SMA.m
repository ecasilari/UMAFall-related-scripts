function salida=Calcula_Energy(ventanas)

%Calcula el Signal Magnitude Area (SMA)
  for i=1:length(ventanas),
          [Nw,temp]=size(ventanas(i).acc);
          SMA=sum(sum(abs(ventanas(i).acc(:,2:4))))/Nw;
          salida(i)=SMA;
  end

end