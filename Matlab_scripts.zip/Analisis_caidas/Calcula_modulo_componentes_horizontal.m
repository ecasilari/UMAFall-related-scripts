function salida=Calcula_modulo_componentes_horizontal(ventanas)

%Calcula la medida del vector formado por los componentes de aceleración qye estaban paralelos al suelo en el instante previo a la caída. 
%Se asume que el acelerómetro se colocó de forma que, en posición erguida, hay un eje colocado de forma completamente perpendicular al suelo 
  
 posiciones=zeros(1,3);
  for i=1:length(ventanas),
          %tiempo=ventanas(i).acc(:,1);
          %[Nw,temp]=size(tiempo);
          %Ts=(max(tiempo)-min(tiempo))/(Nw-1);
          %fs=1/Ts;
          
          acc=ventanas(i).acc(:,2:4);
          %acc=lowpass(acc,1,fs); %No se consiguen ventajas significativas
          %filtrando los componentes altos de la aceleración para quedarse
          %con la gravedad y los cálculos se ralentizan mucho
          
          SMV=sqrt(acc(:,1).^2+acc(:,2).^2+acc(:,3).^2);
          [temp,indice_maximo]=min(SMV);
          acc_previa=acc(1:indice_maximo,:);
          [temp,pos]=max(mean(abs(acc_previa))); %Aquella componente que tenga mayor valor medio antes del impacto se entiende que es la perpendicular al eje vertical

          %disp(['Posición detectada:',num2str(pos)]);
          switch pos
                case 1
                    SMV_H=sqrt(acc(:,2).^2+acc(:,3).^2);
                case 2
                    SMV_H=sqrt(acc(:,1).^2+acc(:,3).^2);
                case 3
                    SMV_H=sqrt(acc(:,1).^2+acc(:,2).^2);
          end
          
          posiciones(pos)=posiciones(pos)+1;
          salida(i)=mean(SMV_H);
  end
  %disp(['Posición detectada:',num2str(posiciones)]);
end