function salida=Calcula_Energy(ventanas)

%Calcula el Signal Magnitude Area (SMA)
%Página de interés: http://aaronscher.com/Course_materials/Communication_Systems/documents/Energy_signals_matlab_tutorial.pdf
  for i=1:length(ventanas),
         [Nw,temp]=size(ventanas(i).acc);
          Ts=(max(ventanas(i).acc(:,1))-min(ventanas(i).acc(:,1)))/(Nw-1);
          fs=1/Ts;
          ax=ventanas(i).acc(:,2);
          ay=ventanas(i).acc(:,3);
          az=ventanas(i).acc(:,4);
          Energy=Ts*(sum(ax.^2)+sum(ay.^2)+sum(az.^2));
          %CÁLCULO CON FFT
          %amplitude_spectrum_x=(1/fs)*abs(fft(ax,Nw));
          %amplitude_spectrum_y=(1/fs)*abs(fft(ay,Nw));
          %amplitude_spectrum_z=(1/fs)*abs(fft(az,Nw));
          %Energy=(fs/Nw)*(sum(amplitude_spectrum_x.^2)+sum(amplitude_spectrum_y.^2)+sum(amplitude_spectrum_z.^2));
          salida(i)=Energy;
  end

end