function salida=Calcula_SMV_skewness(ventanas)

  for i=1:length(ventanas),
          acc=ventanas(i).acc;
          SMV=sqrt(acc(:,2).^2+acc(:,3).^2+acc(:,4).^2);
          salida(i)=skewness(SMV,0); %Calcular sin sesgo
  end

end