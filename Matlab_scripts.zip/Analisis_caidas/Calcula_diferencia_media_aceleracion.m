function salida=Calcula_diferencia_media_aceleracion(ventanas, frecuencia_objetivo)

%Calcula la medida de la diferencia entre muestras consecutivas de la aceleración.
%Previamente sub o sobre-muestrea la señal para que tenga
%cierta frecuencia objetivo. Si no se explicita dicha frecuencia, no se
%produce submuestreo
  
  for i=1:length(ventanas),
          acc=ventanas(i).acc;
          [Nw,temp]=size(acc);
          Ts=(max(acc(:,1))-min(acc(:,1)))/(Nw-1);
          frecuencia_original=1/Ts;
          
          if nargin==1,
              frecuencia_objetivo=frecuencia_original;
          end
          acc_new=resample(acc(:,2:4),round(frecuencia_objetivo),round(frecuencia_original));
          
                  
          SMV=sqrt(acc_new(:,1).^2+acc_new(:,2).^2+acc_new(:,3).^2);
          
          salida(i)=mean(abs(diff(SMV)));
  end

end