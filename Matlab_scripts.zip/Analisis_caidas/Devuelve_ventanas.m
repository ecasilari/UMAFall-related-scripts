function ventanas=Devuelve_ventanas(muestras,no_acelerometro,ventana,tipo)
%Devuelve una estructura con las ventanas alrededor del pico máximo de las
%medidas de cierto acelerómetro.
%
%muestras=estructura con las medidas
%no_acelerometro=no del acelerómetro de interés
%ventana= tiempo en segundos alrededor del máximo. Si ventana es 3 s, se
%         tomarán 1.5 s alrededor del máximo
%tipo= booleano (true, solo caídas, false: solo ADL, si no se da ningún valor, se analizan todas)
contador=1;
for i=1:length(muestras),

    acc=getfield(muestras(i),['Accelerometer_',num2str(no_acelerometro)]);
    
    tipo_actual=muestras(i).Type_boolean;
    if nargin==3,
        tipo_actual=tipo;
    end
    if not(isempty(acc))&(tipo_actual==tipo), %si existe ese acelerómetro en esa muestra
        SMV=sqrt(acc(:,2).^2+acc(:,3).^2+acc(:,4).^2);
        [maximo,indice_maximo]=max(SMV);
        instante_maximo=acc(indice_maximo,1);
        ventana_actual=acc(acc(:,1)>instante_maximo-ventana/2 & acc(:,1)<instante_maximo+ventana/2,:);
        ventanas(contador).acc=ventana_actual;
        contador=contador+1;
    end
end