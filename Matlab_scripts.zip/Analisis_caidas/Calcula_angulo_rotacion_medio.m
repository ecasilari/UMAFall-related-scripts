function salida=Calcula_Angulo_rotacion_medio(ventanas, frecuencia_objetivo)

%Calcula el ángulo de rotación medio entre muestras de aceleración
%consecutivas. Previamente sub o sobre-muestrea la señal para que tenga
%cierta frecuencia objetivo. Si no se explicita dicha frecuencia, no se
%produce submuestreo
  
  for i=1:length(ventanas),
          acc=ventanas(i).acc;
          [Nw,temp]=size(acc);
          Ts=(max(acc(:,1))-min(acc(:,1)))/(Nw-1);
          frecuencia_original=1/Ts;
          
          if nargin==1,
              frecuencia_objetivo=frecuencia_original;
          end
          acc_new=resample(acc(:,2:4),round(frecuencia_objetivo),round(frecuencia_original));
          
          [Nw,temp]=size(acc_new);
          for indice_medida=1:(Nw-1);
                 angulo(indice_medida)=subspace(acc_new(indice_medida,:)', acc_new(indice_medida+1,:)')*180/pi;
          end
          %Ts=(max(ventanas(i).acc(:,1))-min(ventanas(i).acc(:,1)))/(Nw-1);
          %fs=1/Ts;
          salida(i)=mean(angulo);
  end

end