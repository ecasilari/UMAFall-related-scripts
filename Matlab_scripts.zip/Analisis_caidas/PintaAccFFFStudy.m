clear
load('..\Dataset_031_FFFStudy_Falls_window_100s.mat')


frecuencia=50;

for i=1:length(muestras)
    
    acc=muestras(i).Accelerometer_1(frecuencia*27:frecuencia*33,:);
    t=acc(:,1)-acc(1,1);
    ax=acc(:,2);
    ay=acc(:,3);
    az=acc(:,4);
    SMV=sqrt(ax.*ax+ay.*ay+az.*az);
    
    plot(t,SMV);
    xlabel('Time(s)')
    ylabel('Acceleration (in g)');
    legend('SMV')
    
    title(['Evolution of the accelerometry magnitude (Fall no.',num2str(i),' in FFFStudy dataset)'])
    pause
    %xlim
    
end