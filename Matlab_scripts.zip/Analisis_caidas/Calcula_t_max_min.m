function salida=Calcula_t_max_min(ventanas)

  for i=1:length(ventanas),
          acc=ventanas(i).acc;
          SMV=sqrt(acc(:,2).^2+acc(:,3).^2+acc(:,4).^2);
          t=acc(:,1);
          [temp,indice_max]=max(SMV);
          [temp,indice_min]=min(SMV(1:indice_max)); %Valle anterior al máximo
          salida(i)=t(indice_max)-t(indice_min);

  end

end