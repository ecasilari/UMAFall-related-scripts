function salida=Calcula_SMV_maximo(ventanas)

  for i=1:length(ventanas),
          acc=ventanas(i).acc;
          SMV=sqrt(acc(:,2).^2+acc(:,3).^2+acc(:,4).^2);
          salida(i)=max(SMV);
  end

end