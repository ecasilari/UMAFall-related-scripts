function indice_acel=Detecta_no_acelerometro(muestras, posicion)
%Devuelve el número del acelerómetro de cierta muestra que posee el
%acelerómetro puesto en cierta posición. Si no había ninguno devuelve cero

indice_acel=0;
ref=1;
contador=1;

posiciones_acelerometros=muestras(ref).Positions(muestras(ref).Sensor_types=='A',:);

for i=1:size(posiciones_acelerometros,1),
    if contains(upper(posiciones_acelerometros(i,:)),upper(posicion))
       indice_acel=i;
    end
end

return