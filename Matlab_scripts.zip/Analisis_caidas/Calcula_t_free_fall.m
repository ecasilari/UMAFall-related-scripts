function salida=Calcula_t_free_fall(ventanas,umbral)
% salida=Calcula_t_free_fall(ventanas,umbral)
%calcula la duración de una caída libre entendida tal como el tiempo desde
%que el módulo de la aceleración cae por debajo de cierto valor hasta que
%8tras alcanzar el mínimo) vuelve a superar dicho valor
%
% Valor por defecto del umbral=0.9;

if nargin<2,
  umbral=0.9;
end

  for i=1:length(ventanas),
          acc=ventanas(i).acc;
          SMV=sqrt(acc(:,2).^2+acc(:,3).^2+acc(:,4).^2);
          indice_maximo=length(SMV);
          t=acc(:,1);
          [temp,indice_max]=max(SMV);
          [temp,indice_min]=min(SMV(1:indice_max)); %Valle anterior al máximo
          indice_inferior=indice_min;
          indice_superior=indice_min;
          while (SMV(indice_inferior)<umbral)&(indice_inferior>1)
              indice_inferior=indice_inferior-1;
          end
          while (SMV(indice_inferior)<umbral)&(indice_superior<indice_maximo)
              indice_superior=indice_superior+1;
          end
          salida(i)=t(indice_superior)-t(indice_inferior);


  end

end