function salida=Calcula_frecuencia_maximo_espectro(ventanas,fcorte)

%Devuelve la frecuencia donde se alcanza el pico de PSD (power spectral
%density) tras filtrar la señal con un filtro paso alto con cierta frecuencia de
%corte (0.2 Hz por defecto)
  
  if nargin==1,
      fcorte=0.2;
  end
  contador=1;
  for i=1:length(ventanas),
          tiempo=ventanas(i).acc(:,1);
          [Nw,temp]=size(tiempo);
          Ts=(max(tiempo)-min(tiempo))/(Nw-1);
          fs=1/Ts;
          
          acc=ventanas(i).acc(:,2:4);
          SMV=sqrt(acc(:,1).^2+acc(:,2).^2+acc(:,3).^2);
          if length(SMV)>6, %Si hay menos de 6 muestras da error
              [potencias,frecuencias]=pspectrum(highpass(SMV,fcorte,fs),fs);
              [temp,indice_maximo]=max(potencias);
              salida(contador)=frecuencias(indice_maximo);
              contador=contador+1;
          end
  end
end