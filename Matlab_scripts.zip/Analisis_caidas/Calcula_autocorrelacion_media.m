function salida=Calcula_autocorrelacion_media(ventanas, frecuencia_objetivo)

%Calcula la media de los coeficientes de correlación (desde lag=1 hasta el número de muestras de la ventana) 
%del módulo de la aceleración
%Previamente sub o sobre-muestrea la señal para que tenga
%cierta frecuencia objetivo. Si no se explicita dicha frecuencia, no se
%produce submuestreo
  
  for i=1:length(ventanas),
          acc=ventanas(i).acc;
          [Nw,temp]=size(acc);
          Ts=(max(acc(:,1))-min(acc(:,1)))/(Nw-1);
          frecuencia_original=1/Ts;
          
          if nargin==1,
              frecuencia_objetivo=frecuencia_original;
          end
          acc_new=resample(acc(:,2:4),round(frecuencia_objetivo),round(frecuencia_original));
          
                  
          cxx=CORRELA(acc_new,length(acc_new)-1);
          
          salida(i)=mean(cxx(2:end));
  end

end