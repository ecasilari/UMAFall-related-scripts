clear

%bases_a_mirar=[27];
posicion='waist';
posicion2='thigh';
posicion3='pocket';
posicion4='hip';
posicion_usada=posicion;


%disp(['------------------------Estadistico:',char(Nombres_estadisticos(indice_estadistico))]);


load('..\Dataset_031_FFFStudy_Falls_window_100s.mat');     
disp('Analizando FFFStudy');
angulos_FFF=Calcula_angulo_rotacion_antes_despues_caidas(muestras,3,10); %tipo_movimiento_a_estudiar=true (caidas), false (ADL)m, vac�o=todas

clear muestras
disp('Analizando FARSEEING');
load('..\Dataset_013_FARSEEING_v2.mat');
angulos_FS=Calcula_angulo_rotacion_antes_despues_caidas(muestras,10,100); %tipo_movimiento_a_estudiar=true (caidas), false (ADL)m, vac�o=todas
     
eje_FS=1:length(angulos_FS);
eje_FFF=1:length(angulos_FFF);
        

%plot(eje_FS,angulos_FS,'*',eje_FFF,angulos_FFF,'o');

hist([angulos_FS,angulos_FFF])
xlabel('Angle (deg.) between the mean acceleration vectors before and after the fall')
ylabel('Number of occurrences');
title('Histogram of the rotation angle provoked in the acceleration by the falls (FFFStudy&FARSEEING datasets)')


