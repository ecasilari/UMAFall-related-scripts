clear
warning off
system('taskkill /F /IM EXCEL.EXE'); %Cierro excel
raiz='..\';
bases_datos=dir([raiz,'Dataset_0*.mat']);
fichero_salida='fichero_salida';
confianza=95;

%-------------------------------------------------------------------------
%---------------ANALISIS DE UNA CARACTER�STICAS PARA BOPXPLOT
%-------------------------------------------------------------------------
bases_a_mirar=[31 13 25 7 1 18 15 27 8 9 21 30 3 11 5 4 10 12 17 6];
%bases_a_mirar=[31 13 1 4];
Nombres_estadisticos={...
    'Maximum SMV (g)',
    'Minimum SMV (g)'};
indice_boxplot_a_calcular=2;
tipo_movimiento_a_estudiar=false; %se estudian ADLS de todas los datasets sint�ticos
tipo_movimiento_a_estudiar=true; %se estudian las ca�das de todas los datasets sint�ticos
calcular_boxplot=true;



%-------------------------------------------------------------------------
%---------------ANALISIS DE TODAS LAS CARACTER�STICAS Y LAS BASES DE DATOS
%-------------------------------------------------------------------------
bases_a_mirar=[31 13 25 7 1 18 15 27 8 9 21 30 3 11 5 4 10 12 17 6];
Nombres_estadisticos={...
    'Maximum SMV (g)',...
    'Minimum SMV (g)',...
    'Mean SMV (g)',...
    'Standard deviation of SMV (g)',...
    'Skewness of SMV (g)',...
    'Time between maximum and minimum SMV (s)',...
    'Fre-fall time',...
    'Mean difference between consecutive values of SMV (g)',...
    'Number of acceleration peaks during the fall',...
    'Signal Magnitude Area (SMA)',...
    'Energy',...
    'Mean rotation angle of consecutive samples (deg)',...
    'Mean magnitude of the initially horizontal acceleration components',...
    'Frequency of maximum PSD',...
    'Mean of the autocorrelation function of SMV'};
tipo_movimiento_a_estudiar=true; %se estudian ca�das
calcular_boxplot=false;






%bases_a_mirar=[27];
posicion='waist';
posicion2='thigh';
posicion3='pocket';
posicion4='hip';
posicion_usada=posicion;
tam_ventana=2;


xlswrite(fichero_salida,cellstr(Nombres_estadisticos),1,[char(66),num2str(1)]);

no_estadisticos=length(Nombres_estadisticos);
est{no_estadisticos}=[];
marcador_BD{no_estadisticos}=[];
limites{no_estadisticos}=[];


%disp(['------------------------Estadistico:',char(Nombres_estadisticos(indice_estadistico))]);


for indice_BD=1:length(bases_a_mirar),

        base_actual=dir([raiz,'Dataset_',num2str(bases_a_mirar(indice_BD),'%03.f'),'*.mat']);
        nombre_base_actual=erase(erase(base_actual(1).name(13:end),'_v2.mat'),'.mat');
        nombre_base_actual=erase(nombre_base_actual,'_');
        nombre_base_actual=erase(nombre_base_actual,'Fallswindow100s');
        nombre_base_actual=erase(nombre_base_actual,'onlyAccelerometerGyroscopeonlywaist');
        nombres_bases_datos(indice_BD)={nombre_base_actual};

        clear muestras;
        load([raiz,base_actual(1).name]);
        indice_acel=Detecta_no_acelerometro(muestras, posicion);
        posicion_usada=posicion;
        if indice_acel==0, %si no hay sensor en la cintura, busco en el muslo
            indice_acel=Detecta_no_acelerometro(muestras, posicion2);
            nombres_bases_datos(indice_BD)={[nombre_base_actual ' (Th)']};
            posicion_usada=posicion2;
        end
        if indice_acel==0, %si no hay sensor en la cintura ni en muslo, busco en bolsillo
            indice_acel=Detecta_no_acelerometro(muestras, posicion3);
            nombres_bases_datos(indice_BD)={[nombre_base_actual ' (Th)']};
            posicion_usada=posicion3;
        end
        if indice_acel==0, %si no hay sensor en la cintura ni en muslo, ni en bolsillo, busco en la cadera
            indice_acel=Detecta_no_acelerometro(muestras, posicion4);
            nombres_bases_datos(indice_BD)={[nombre_base_actual ' (Hip)']};
            posicion_usada=posicion4;
        end

        disp(['Cargando:',nombre_base_actual,' Aceler�metro: ',num2str(indice_acel),' (',posicion_usada,')']);

        if strcmp(nombre_base_actual,'FFFStudy'),
            for i=1:49;
                validas=(muestras(i).Accelerometer_1(:,1)>25)&(muestras(i).Accelerometer_1(:,1)<35); %Para FFFStudy el an�lisis se centra entre los segundos 25 y 35
                muestras(i).Accelerometer_1=muestras(i).Accelerometer_1(validas,:);
                muestras(i).Accelerometer_1(:,1)=muestras(i).Accelerometer_1(:,1)-muestras(i).Accelerometer_1(1,1);
            end 
        end
        
        tipo_movimiento_a_estudiar_actual=tipo_movimiento_a_estudiar;
        if or(strcmp(nombre_base_actual,'FFFStudy'),strcmp(nombre_base_actual,'FARSEEING')), %si la base de datos es FFFstudy o FARSEEING solo se analizan las ca�das porque no hay ADLs
            tipo_movimiento_a_estudiar_actual=true;
        end        
  
        
        ventanas=Devuelve_ventanas(muestras,indice_acel,tam_ventana,tipo_movimiento_a_estudiar_actual); %tipo_movimiento_a_estudiar=true (caidas), false (ADL)m, vac�o=todas

        
        for indice_estadistico=1:no_estadisticos,
              

                switch indice_estadistico
                case 1 %M�ximo del m�dulo de la aceleraci�n
                    estadistico=Calcula_SMV_maximo(ventanas);
                    limites{indice_estadistico}=[0 16];
                case 2 %M�nimo del m�dulo de la aceleraci�n
                    estadistico=Calcula_SMV_minimo(ventanas);
                    limites{indice_estadistico}=[0 1.1];
                case 3 %Media del m�dulo de la aceleraci�n
                    estadistico=Calcula_SMV_medio(ventanas);
                    limites{indice_estadistico}=[0 4];
                case 4 %Desviaci�n estad�stica del m�dulo de la aceleraci�n
                    estadistico=Calcula_SMV_desvi(ventanas);
                    limites{indice_estadistico}=[0 4];
                case 5 %�ndice de asimetr�a del m�dulo de la aceleraci�n
                    estadistico=Calcula_SMV_skewness(ventanas);
                    limites{indice_estadistico}=[0 4];
                case 6 %tiempo entre m�ximo y m�nimo
                    estadistico=Calcula_t_max_min(ventanas);
                    limites{indice_estadistico}=[0 1];
                case 7 %tiempo de duracion ca�da libre
                    umbral_free_fall=0.9;
                    estadistico=Calcula_t_free_fall(ventanas,umbral_free_fall);
                    limites{indice_estadistico}=[0 1];
                case 8 %Media de la diferencia de SMV consecutivas
                    frecuencia_objetivo=20;
                    estadistico=Calcula_diferencia_media_aceleracion(ventanas, frecuencia_objetivo);
                    limites{indice_estadistico}=[0 5];
                case 9 %No picos (m�ximos locales) habidos durante la ventana y superiores a umbral 
                    umbral=2; 
                    estadistico=Calcula_no_picos(ventanas,umbral);
                    limites{indice_estadistico}=[1 8];
                case 10 %Signal Magnitude Area
                    estadistico=Calcula_SMA(ventanas);
                    limites{indice_estadistico}=[1 2.5];
                case 11 %Energ�a
                    estadistico=Calcula_Energy(ventanas);
                    limites{indice_estadistico}=[1 20];
                case 12 %�ngulo de rotaci�n medio cuando la se�al es resubmuestreada a una frecuencia constante y com�n para todas las bases de datos
                    frecuencia_objetivo=20;
                    estadistico=Calcula_angulo_rotacion_medio(ventanas, frecuencia_objetivo);
                    limites{indice_estadistico}=[0 50];
                case 13 %Media del vector de las componentes inicialmente horizontales de la aceleraci�n
                    estadistico=Calcula_modulo_componentes_horizontal(ventanas);
                     limites{indice_estadistico}=[0 2];
                case 14 %Frecuencia de m�ximo PSD
                    fcorte=0.2;
                    estadistico=Calcula_frecuencia_maximo_espectro(ventanas,fcorte);
                    limites{indice_estadistico}=[0 5];
                case 15 %Autocorrelaci�n media
                    frecuencia_objetivo=20;
                    estadistico=Calcula_autocorrelacion_media(ventanas, frecuencia_objetivo);
                    limites{indice_estadistico}=[0 1];
                end
                
                est{indice_estadistico}=[est{indice_estadistico},estadistico];
                marcador_BD{indice_estadistico}= [marcador_BD{indice_estadistico},(ones(1,length(estadistico))*indice_BD)];

                [media(indice_BD,indice_estadistico), intervalo(indice_BD,indice_estadistico),t]=tstudent(estadistico,confianza,false);

                xlswrite(fichero_salida,cellstr(nombres_bases_datos(indice_BD)),1,[char(65),num2str(indice_BD+1)]);
                xlswrite(fichero_salida,cellstr([num2str(media(indice_BD,indice_estadistico),'%.3f'),char(177),num2str(intervalo(indice_BD,indice_estadistico),'%.3f')]),1,[char(65+indice_estadistico),num2str(indice_BD+1)]);
                %pause
                
                
         end %for estadistico
end %for base_datos


bases_datos_diferentes_FFFStudy=zeros(1,no_estadisticos);
bases_datos_diferentes_FARSEEING=zeros(1,no_estadisticos);
no_estadisticos_diferentes_FFFStudy=zeros(1,length(bases_a_mirar)-2);
no_estadisticos_diferentes_FARSEEING=zeros(1,length(bases_a_mirar)-2);


for indice_estadistico=1:no_estadisticos,
    limite_inferior_referencia_FFFStudy=media(1,indice_estadistico)-intervalo(1,indice_estadistico); %FFFStudy debe ser la primera base de datos
    limite_superior_referencia_FFFStudy=media(1,indice_estadistico)+intervalo(1,indice_estadistico);
    limite_inferior_referencia_FARSEEING=media(2,indice_estadistico)-intervalo(2,indice_estadistico); %FARSEEING debe ser la segunda base de datos
    limite_superior_referencia_FARSEEING=media(2,indice_estadistico)+intervalo(2,indice_estadistico);

    for indice_BD=3:length(bases_a_mirar),
        limite_inferior_actual=media(indice_BD,indice_estadistico)-intervalo(indice_BD,indice_estadistico);
        limite_superior_actual=media(indice_BD,indice_estadistico)+intervalo(indice_BD,indice_estadistico);
        
        if (limite_superior_referencia_FFFStudy<limite_inferior_actual)|(limite_inferior_referencia_FFFStudy>limite_superior_actual)
           bases_datos_diferentes_FFFStudy(indice_estadistico)=bases_datos_diferentes_FFFStudy(indice_estadistico)+1;
           no_estadisticos_diferentes_FFFStudy(indice_BD-2)=no_estadisticos_diferentes_FFFStudy(indice_BD-2)+1;
        end
        if (limite_superior_referencia_FARSEEING<limite_inferior_actual)|(limite_inferior_referencia_FARSEEING>limite_superior_actual)
           bases_datos_diferentes_FARSEEING(indice_estadistico)=bases_datos_diferentes_FARSEEING(indice_estadistico)+1;
           no_estadisticos_diferentes_FARSEEING(indice_BD-2)=no_estadisticos_diferentes_FARSEEING(indice_BD-2)+1;
        end

    end
end

xlswrite(fichero_salida,cellstr('Number of datasets with a significantly different mean with respect to FFFStudy'),1,['A',num2str(length(bases_a_mirar)+3)]);
xlswrite(fichero_salida,bases_datos_diferentes_FFFStudy,1,['B',num2str(length(bases_a_mirar)+3)]);
xlswrite(fichero_salida,cellstr('Number of datasets with a significantly different mean with respect to FARSEEING'),1,['A',num2str(length(bases_a_mirar)+4)]);
xlswrite(fichero_salida,bases_datos_diferentes_FARSEEING,1,['B',num2str(length(bases_a_mirar)+4)]);
 
xlswrite(fichero_salida,cellstr('Number of statistics with a significantly different mean with respect to those of FFFStudy'),1,[char(no_estadisticos+66),num2str(1)]);
xlswrite(fichero_salida,cellstr('Number of statistics with a significantly different mean with respect to those of FARSEEING'),1,[char(no_estadisticos+67),num2str(1)]);



for i=1:(length(bases_a_mirar)-2)
   xlswrite(fichero_salida, no_estadisticos_diferentes_FFFStudy(i),1,[char(no_estadisticos+66),num2str(i+3)]);
   xlswrite(fichero_salida, no_estadisticos_diferentes_FARSEEING(i),1,[char(no_estadisticos+67),num2str(i+3)]);

end

if calcular_boxplot,
    boxplot(est{indice_boxplot_a_calcular},marcador_BD{indice_boxplot_a_calcular},'Labels',nombres_bases_datos)
    xlabel('Dataset');
    ylabel(Nombres_estadisticos(indice_boxplot_a_calcular));
    set(gca,'FontSize',10,'XTickLabelRotation',90);
    ylim(limites{indice_boxplot_a_calcular});                
end
