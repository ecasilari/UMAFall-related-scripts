function salida=Calcula_SMV_minimo(ventanas)

  for i=1:length(ventanas),
          acc=ventanas(i).acc;
          SMV=sqrt(acc(:,2).^2+acc(:,3).^2+acc(:,4).^2);
          salida(i)=min(SMV);
  end

end