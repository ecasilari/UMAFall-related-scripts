function salida=Calcula_no_picos(ventanas,umbral)
% Cálcula el número de picos (máximos locales) del módulo de la aceleración que se producen que superan el
% un cierto umbral
% Si no se da umbral, este vale 2g
%
%Nota: para ser considerada un pico (se exige que una muestra sea mayor a las dos anteriores y a las dos posteriores 

if nargin==1,
    umbral=2;
end
  for i=1:length(ventanas),
          acc=ventanas(i).acc;
          SMV=sqrt((acc(:,2).^2)+(acc(:,3).^2)+(acc(:,4).^2));
          %umbral=max(SMV)*porcentaje/100;
          %salida(i)=sum(SMV>umbral);
          picos=findpeaks(SMV);
          salida(i)=sum(picos>umbral);
          
  end

end