function salida=Calcula_angulo_rotacion_antes_despues_caidas(muestras, t_previo, t_final)

%Calcula el ángulo de rotación entre la aceleración media previa y
%posterior a una caída (pensado para FFFStudy y FARSEEING)
% salida=vector con los ángulos de desplazamiento (uno por muestra)
%
% muestras: muestras a las que se pretende calcular los ángulos
% t_previo: número de segundos iniciales de la muestra para los que se calculara la aceleración media previa
% t_final: número de segundos finales de la muestra para los que se calculara la aceleración media previa
  for i=1:length(muestras),
          
          acc=muestras(i).Accelerometer_1;
          [Nw,temp]=size(acc);
          Ts=(max(acc(:,1))-min(acc(:,1)))/(Nw-1);

          indice_previo=round(t_previo/Ts);
          indice_final=Nw-round(t_final/Ts);
  
          
          acc_previa=acc(1:indice_previo,2:4);
          acc_post=acc(indice_final:Nw,2:4);
          
          
          acc_media_previa=mean(acc_previa);
          acc_media_post=mean(acc_post);
        
          
          
          angulo=subspace(acc_media_previa', acc_media_post')*180/pi;
          disp(['Angulo de la muestra ',num2str(i),':',num2str(angulo)]);
          salida(i)=angulo;
  
  end

end